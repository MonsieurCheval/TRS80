;***********************************************************************
;
;M - Execute multiple commands on one line
;
;        Author: Steve Mann [73145,473]
;        Date: 09/17/84
;
;        Syntax: M command1;command2;command3<CR>
;
;***********************************************************************
;
*GET TRSDOS6/MAC
;
	ORG	3000H
;
BEGIN	LD	DE,BUFFER	;point at internal cmd line buffer
	LD	BC,80		;move 80 bytes
	LDIR			;move
;
	LD	HL,BUFFER	;point at buffer
;
PARSE	LD	(HL1),HL	;save start of this command
PARSE2	LD	A,(HL)		;get character to parse
	CP	0DH		;carriage return?
	JR	Z,LASTCMD	;yes, this is the last command
	CP	';'		;command seperator?
	JR	Z,EXECMD	;yes, go execute command
	INC	HL		;point to next character
	JR	PARSE2		;continue parsing
;
EXECMD	LD	A,0DH		;carriage return
	LD	(HL),A		;stuff it in 
	INC	HL		;point at start of next command
	LD	(HL2),HL	;save its location
	LD	HL,(HL1)	;get start of current command
	@CMNDR			;execute it and return
	LD	HL,(HL2)	;point at start of next command
	JR	PARSE		;go do again
;
LASTCMD	LD	HL,(HL2)	;point at start of command
	@CMNDI			;execute it and exit to system
;
HL1	DW	0
HL2	DW	BUFFER
BUFFER	EQU	$
	END	BEGIN

