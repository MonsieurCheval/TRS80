1 RANDOM
10 REM Numeric Master Mind by Randall Rhea 1/87
15 DEFINT A-Z
20 CLS
30 DIM CG(5):REM COMPUTER'S NUMBER
40 DIM NG(5):REM PLAYER'S GUESS
42 DIM CF(5):REM FLAG TO AVOID DUPLICATES
44 DIM NF(5)
50 PRINT CHR$(15);
60 RANDOM
100 REM     * * * * * THE TITLE SUBROUTINE * * * * *
110 Q=16:O=400
120 DATA "::O::O::O::O::O::O::O::O::O::O::O::O::O:"
130 DATA ":O::O::O::O::O::O::O::O::O::O::O::O::O::"
140 DATA "O::O::O::O::O::O::O::O::O::O::O::O::O::O"
150 FOR C=1 TO 3:READ D$(C):NEXT C
160 RESTORE
170 FOR C=3 TO 1 STEP -1:READ E$(C):NEXT C
180 PRINT CHR$(15)
190 GOSUB 250
200 D=D+1: FOR C=1 TO 3:PRINT @160,E$(C);:PRINT @960+O,D$(C);:NEXT C
210 I$=INKEY$:IF I$="" AND D<20  THEN GOTO 200 ELSE 220
220 Q=Q+1:IF Q>17 THEN Q=16
230 PRINT CHR$(Q);:IF D<30 THEN GOTO 200
240 GOTO 1000
250 REM
260 CLS:PRINT:PRINT:PRINT:PRINT
270 PRINT CHR$(23):PRINT CHR$(16):PRINT:PRINT"  ****** Numeric Master Mind ******" ;:PRINT
280 PRINT CHR$(17):PRINT:PRINT:PRINT TAB(19)"by":PRINT:PRINT TAB(14)"Randall Rhea"
290 RETURN
1000 REM INSTRUCTIONS?
1005 CLS
1010 PRINT @(10,15),"Would you like instructions? (Y/N) "
1020 CHOICE$=INKEY$:IF CHOICE$="" THEN GOTO 1020
1030 IF (CHOICE$="Y") OR (CHOICE$="y") THEN GOSUB 9000
1100 REM DRAW SCREEN
1105 CLS
1110 REM VERTICAL AND HORIZONTAL LINES
1120 FOR X=1 TO 21:PRINT @(X,15),CHR$(149);:NEXT X
1130 FOR X=1 TO 20:PRINT @(X,56),CHR$(170);:NEXT X
1134 FOR X=1 TO 20:PRINT @(X,40),CHR$(170);:NEXT X
1136 FOR X=1 TO 20:PRINT @(X,24),CHR$(170);:NEXT X
1140 PRINT @(21,15),"";:FOR X=1 TO 42:PRINT CHR$(131);:NEXT X
1144 PRINT @(1,15),CHR$(151);:FOR X=1 TO 40:PRINT CHR$(131);:NEXT X:PRINT CHR$(171);
1146 PRINT @(1,40),CHR$(171);:PRINT @(1,24),CHR$(171);
1150 Y=10:FOR X=2 TO 20 STEP 2:PRINT @(X,17),Y;:Y=Y-1:NEXT X
1160 PRINT @(0,1),"      ***************   Numeric Master Mind   ****************";
1200 REM GENERATE COMPUTER'S NUMBER
1210 FOR X=1 TO 4
1220 GG=RND(10)-1
1230 CG(X)=GG
1240 NEXT X
2000 REM GET GUESS
2005 G=0
2010 P=20
2020 G=G+1
2024 IF G>10 THEN GOTO 6000: REM MORE THAN 10 GUESSES, PLAYER LOSES
2025 HP=27
2027 GN=0
2030 PRINT CHR$(14);
2040 PRINT @(P,29),"       ";
2047 PRINT @(23,1),CHR$(30);
2048 PRINT @(23,8),"Type in your guess, <S> to start over, or <Q> to quit.";
2050 PRINT @(P,29),"";
2100 FOR X=1 TO 4
2110 U$=INKEY$:IF U$="" THEN GOTO 2110
2115 IF U$="S" OR U$="s" THEN GOTO 1100
2117 IF U$="Q" OR U$="q" THEN SYSTEM
2118 IF U$<"0" OR U$>"9" THEN GOTO 2110
2220 GN=GN+1
2225 HP=HP+2
2230 PRINT @(P,HP),U$;:PRINT @(P,HP+1)," ";
2240 NG(GN)=VAL(U$)
2250 NEXT X
2300 REM IS THE GUESS OK?
2310 PRINT @(23,1),CHR$(30);
2320 PRINT @(23,10),"Your guess is ";NG(1);NG(2);NG(3);NG(4);".  Is this OK? (Y/N) ";
2330 CO$=INKEY$:IF CO$="" THEN GOTO 2330
2340 IF CO$="Y" OR CO$="y" THEN GOTO 3000 ELSE GOTO 2025
3000 REM EVALUATE GUESS
3002 ERASE NF
3004 ERASE CF
3005 HP=45
3010 PRINT @(P,HP),"";
3020 FOR X=1 TO 4
3030 IF CG(X)=NG(X) THEN PRINT "X ";:NF(X)=1:CF(X)=1
3040 IF NF(1)=1 AND NF(2)=1 AND NF(3)=1 AND NF(4)=1 THEN GOTO 7000
3050 NEXT X
3060 FOR X=1 TO 4
3065 IF NF(X)=1 THEN GOTO 3100: REM NUMBER ALREADY MATCHED, SKIP IT
3070 FOR Y=1 TO 4
3080 IF NG(X)=CG(Y) AND CF(Y)=0 THEN PRINT "O ";:CF(Y)=1:GOTO 3100
3090 NEXT Y
3100 NEXT X
3200 P=P-2
3210 GOTO 2020
6000 REM PLAYER LOSES
6010 PRINT @(23,1),CHR$(30);
6015 PRINT@(22,15),"The computer's number was: ";CG(1);CG(2);CG(3);CG(4);
6020 PRINT @(23,6),"**** Sorry, but you lose. ****  Care to play again? (Y/N) ";
6030 GOTO 7030
7000 REM "PLAYER WINS!"
7010 PRINT @(23,1),CHR$(30);
7020 PRINT @(23,10),"**** You WIN! ****   Care to play again? (Y/N) ";
7030 CO$=INKEY$:IF CO$="" GOTO 7030
7040 IF CO$="Y" OR CO$="y" THEN GOTO 1100
7050 SYSTEM
9000 REM INSTRUCTIONS- DELETE THIS SUBROUTINE IF INSTRUCTIONS ARE NOT NEEDED
9010 CLS
9015 PRINT CHR$(14);
9020 PRINT @(2,30),CHR$(16);"MASTER MIND";CHR$(17)
9030 PRINT @(4,10),"MASTER MIND is one of the most popular board games in the "
9040 PRINT @(5,10),"entire world.  The classic version of this game involves"
9050 PRINT @(6,10),"guessing colors, but more recent versions, as well as this"
9060 PRINT @(7,10),"one, involve numbers."
9070 PRINT @(9,10),"You will get 10 attempts to guess a 4-digit number between"
9080 PRINT @(10,10),"0000 and 9999.  After each guess, the computer will give"
9090 PRINT @(11,10),"you one of two clues; 'X' means that a digit in your guess"
9100 PRINT @(12,10),"is a correct digit in the correct position; an 'O' means"
9110 PRINT @(13,10),"that a digit is correct, but in the wrong position.  For"
9120 PRINT @(14,10),"example, if the computer's number is 8424:"
9130 PRINT @(16,10),"If you guess:                   The computer will respond:"
9140 PRINT @(18,10),"  8 5 1 2                               X O"
9150 PRINT @(19,10),"  7 3 5 9                    "
9160 PRINT @(20,10),"  2 4 4 4                               X X O"
9170 PRINT @(22,7), "Good luck and have fun!  Press <RETURN> to play: ";
9180 A$=INKEY$:IF A$="" THEN GOTO 9180
9990 RETURN
