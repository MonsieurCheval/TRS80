1 OPEN "r",1,"phonelst/df",80:FIELD #1, 22 AS N$,14 AS NUMBER$,22 AS ADD1$,22 AS ADD2$:LSET N$="Tandy Test Name":LSET NUMBER$="123-4567":LSET ADD1$="One Tandy Plaza":LSET ADD2$="Fort Worth Tx. 33333":PUT#1,1:CLOSE 1
2 CLS:PRINT CHR$(16);"Initialization Completed";CHR$(17);"...You MUST now type save''phonelst/bas'', and save program as initialization      lines have been deleted.":DELETE 1-2
3 ON ERROR GOTO 11:POKE &H3AF,&H18:CLS:PRINT CHR$(16);:PRINT@0,"|||||||||||||||||||||||||||||||| PHONE LISTING |||||||||||||||||||||||||||||||||";:PRINT@829," Opening Data File ";
4 OPEN "R",1,"PHONELST/DF",80
5 FIELD 1,22 AS N$,14 AS NUMBER$,22 AS ADD1$,22 AS ADD2$
6 PRINT@989,"   Reading Data..  ";
7 DIM A$((LOF(1)+25),4)
8 FOR R=1 TO LOF(1):GET# 1,R:A$(R,1)=N$:A$(R,2)=NUMBER$:A$(R,3)=ADD1$:A$(R,4)=ADD2$
9 NEXT
10 UPDATE=0:ADDED=0
11 CLS:PRINT CHR$(23); CHR$(15); CHR$(16);'40 CHAR/CURSOROFF
12 PRINT@2,"{c} mcmlxxxv rickWare   |   phonelst ";
13 PRINT@254," P  H  O  N  E  L  S  T ";
14 PRINT@414," H ";:PRINT@574," O ";:PRINT@734," N ";:PRINT@894," E ";
15 PRINT@432," U ";:PRINT@592," M ";:PRINT@752," B ";:PRINT@912," E ";:PRINT@1072," R E M I N D E R ";:PRINT@1238,"version 3.0";
16 PRINT@1680,"";
17 '******************** MENU CHOICES ***********************************
18 PRINT CHR$(16);:PRINT CHR$(23);:GLOBAL=0
19 SOUND 5,0
20 PRINT@(21,2),"1";
21 PRINT@(21,12),"2";
22 PRINT@(21,28),"3";
23 PRINT@(21,44),"4";
24 PRINT@(21,60),"5";
25 PRINT@(23,28),"9";
26 Z$=INKEY$
27 PRINT@(21,4),"ADD";
28  PRINT@(21,14),"BROWSE";
29 PRINT@(21,30),"SEARCH";
30 PRINT@(21,46),"UPDATE";
31 PRINT@(21,62),"GLOBAL";
32 PRINT@(23,30),"ESCAPE";
33 IF Z$<>"" THEN 38
34 FOR I=1 TO 600:NEXT
35 PRINT@(21,4),"   ";:PRINT@(21,14),"      ";:PRINT@(21,30),"      ";:PRINT@(21,46),"      ";:PRINT@(21,62),"      ";:PRINT@(23,30),"      ";
36 FOR I=1 TO 50:NEXT
37 IF Z$="" THEN 26
38 IF Z$="P" OR Z$="p" THEN GOSUB 197
39 Z=VAL(Z$)
40 IF Z=0 THEN 26
41 ON Z GOTO 42,176,88,119,88,17,17,17,153,17
42 '******************* ADD MODULE **************************************
43 CLS:PRINT CHR$(23);
44 IF UPDATE$<>"YES" THEN 50
45 PRINT@0,"[...UPDATING...]";
46 PRINT@80,"Name     : ";A$(R,1);
47 PRINT@160,"Number   : ";A$(R,2);
48 PRINT@240,"Address  : ";A$(R,3);
49 PRINT@342,A$(R,4);
50 PRINT@806,STRING$(15,244);CHR$(245);CHR$(246);"     Add a record ";
51 IF UPDATE$="YES" THEN PRINT@848,"Update";
52 PRINT@882,STRING$(36,"_");
53 PRINT@1154,STRING$(22,"_");
54 PRINT@1042,"Enter new name :";:LINE INPUT NN$
55 IF UPDATE$="YES" AND NN$="" THEN NN$=A$(R,1):PRINT@1074,A$(R,1);
56 PRINT@1314,STRING$(14,"_");
57 PRINT@1202,"Enter number   :";:LINE INPUT NUM$
58 IF UPDATE$="YES" AND NUM$="" THEN NUM$=A$(R,2):PRINT@1234,A$(R,2);
59 PRINT@1474,STRING$(22,"_");
60 PRINT@1362,"Address        :";:LINE INPUT AD1$
61 IF UPDATE$="YES" AND AD1$="" THEN AD1$=A$(R,3):PRINT@1394,A$(R,3);
62 IF AD1$="" THEN 66
63 PRINT@1634,STRING$(22,"_");
64 PRINT@1522,"City/state/zip :";:LINE INPUT AD2$
65 IF UPDATE$="YES" AND AD2$="" THEN AD2$=A$(R,4):PRINT@1554,A$(R,4);
66 PRINT CHR$(16);
67 Z$=INKEY$
68 PRINT@804," write record {Y/N} ? ";
69 FOR I=1 TO 300:NEXT
70 PRINT@804,STRING$(22," ");
71 FOR I=1 TO 50:NEXT
72 IF Z$="" THEN 67
73 GOSUB 174
74 IF Z$="N" THEN UPDATE$="NO":GOTO 17
75 IF Z$<>"Y" THEN 67
76 '******************** write to disk *****************
77 IF UPDATE$="YES" THEN UPDATE=UPDATE+1:GOTO 80
78 ADDED=ADDED+1
79 R=LOF(1)+1
80 R$=STR$(R)
81 LSET N$=NN$:A$(R,1)=NN$
82 LSET NUMBER$=NUM$:A$(R,2)=NUM$
83 LSET ADD1$=AD1$:A$(R,3)=AD1$
84 LSET ADD2$=AD2$:A$(R,4)=AD2$
85 PUT# 1,R
86 UPDATE$="NO"
87 GOTO 17
88 '************************* search module *******************************
89 CLS:PRINT CHR$(23);:IF Z=5 THEN GLOBAL=1
90 PRINT@804,STRING$(15,244);CHR$(245);CHR$(246);"   Search for number";
91 PRINT@882,STRING$(38,"_");
92 PRINT@1152,STRING$(22,"_")
93 IF GLOBAL=1 THEN PRINT@804,CHR$(16);STRING$(11,160);"GLOBAL";CHR$(17);
94 PRINT@1042," Enter name   :";:LINE INPUT NN$
95 IF GLOBAL=1 THEN 202
96 SIZE=LEN(NN$)
97 FOR R=1 TO LOF(1)
98 X$=LEFT$(A$(R,1),SIZE)
99 IF X$=NN$ THEN 111
100 NEXT
101 SOUND 0,0:PRINT CHR$(16);
102 Z$=INKEY$
103 PRINT@802," Can't find, retry ?";
104 FOR I=1 TO 300:NEXT
105 PRINT@804,STRING$(19," ");
106 FOR I=1 TO 50:NEXT
107 IF Z$="" THEN 102
108 GOSUB 174
109 IF Z$="Y" THEN 88
110 IF Z$<>"N" THEN 102 ELSE 17
111 '************** POST NUMBER *************
112 CLS:PRINT CHR$(23)
113 PRINT@0,"Rec #";R;:PRINT@60,"<P> PRINT";
114 PRINT@826,A$(R,2);
115 PRINT@966,"Name     :";A$(R,1);
116 PRINT@1126,"Address  :";A$(R,3);
117 PRINT@1226,A$(R,4);
118 GOTO 17
119 '************************* update module *******************************
120 CLS:PRINT CHR$(23):IF LIMIT=1 THEN 10
121 PRINT@804,STRING$(14,244);CHR$(245);CHR$(246);"     Update a record";
122 PRINT@882,STRING$(38,"_");
123 PRINT@1238,STRING$(22,"_");
124 PRINT@1124,"Name to update  :";:LINE INPUT NN$
125 SIZE=LEN(NN$)
126 FOR R=1 TO LOF(1)
127 X$=LEFT$(A$(R,1),SIZE)
128 IF X$=NN$ THEN 138
129 NEXT
130 PRINT CHR$(16);
131 Z$=INKEY$
132 PRINT@804," Can't find, retry ?";:FOR I=1 TO 300:NEXT
133 PRINT@804,STRING$(20," ");
134 FOR I=1 TO 50:NEXT
135 IF Z$="" THEN 131 ELSE GOSUB 174
136 IF Z$="Y" THEN 119
137 IF Z$<>"N" THEN 131 ELSE 17
138 PRINT@0,"Rec #";R;
139 PRINT@80,"Name    :";A$(R,1);
140 PRINT@160,"Number  :";A$(R,2);
141 PRINT@240,"Address :";A$(R,3);
142 PRINT@338,A$(R,4);
143 PRINT CHR$(16);
144 Z$=INKEY$
145 PRINT@804," Update record ? ";
146 FOR I=1 TO 300:NEXT
147 PRINT@804,STRING$(15," ");
148 FOR I=1 TO 50:NEXT
149 IF Z$="" THEN 144
150 GOSUB 174
151 IF Z$="Y" THEN UPDATE$="YES":GOTO 42
152 IF Z$<>"N" THEN SOUND 0,0:GOTO 144 ELSE 17
153 '************************* escape module *******************************
154 CLS:PRINT CHR$(16);
155 IF UPDATE=0 AND ADDED=0 THEN 172
156 PRINT@264," You have updated,......... ";UPDATE;
157 PRINT@344," and have added.... ";ADDED;"records.";
158 PRINT@832," SORTING....";
159 FOR R=1 TO LOF(1)-1
160 FOR J=R+1 TO LOF(1)
161 IF A$(R,1)> A$(J,1) THEN SWAP A$(R,1),A$(J,1):SWAP A$(R,2),A$(J,2):SWAP A$(R,3),A$(J,3):SWAP A$(R,4),A$(J,4) ELSE 162
162 NEXT:NEXT 
163 PRINT@992,"  WRITING...";
164 FOR R=1 TO LOF(1)
165 LSET N$=A$(R,1)
166 LSET NUMBER$=A$(R,2)
167 LSET ADD1$=A$(R,3)
168 LSET ADD2$=A$(R,4)
169 PUT# 1,R
170 NEXT
171 PRINT@1232,"  CLOSING...";
172 CLOSE 1:CLS:SYSTEM
173 '************************* convert lower to upper case *****************
174 Z=ASC(Z$):IF Z>96 THEN Z$=CHR$(Z-32)
175 RETURN
176 '****************** BROWSE MODULE ***********************************
177 CLS:PRINT CHR$(23):IF LIMIT=1 THEN 10
178 PRINT@220,"<P>rint";
179 PRINT@806,STRING$(15,244);CHR$(245);CHR$(246);"    BROWSE MODULE";
180 PRINT@884,STRING$(36,"_");
181 FOR R=1 TO LOF(1)
182 IF R<1 THEN R=LOF(1)
183 PRINT@0,"Rec #";R;
184 PRINT@1066,A$(R,2);
185 PRINT@1130,"Name  : ";A$(R,1);
186 PRINT@1204,"Address  : ";A$(R,3);
187 PRINT@1306,A$(R,4);
188 PRINT@(22,0),"-->for next  |  for last<--  | <9>escape";
189 Z$=INKEY$:IF Z$="" THEN 189
190 IF Z$="9" THEN CLS:GOTO 17
191 IF Z$=CHR$(8) THEN R=R-1:GOTO 182
192 IF Z$="p" OR Z$="P" THEN GOSUB 197
193 IF Z$<>CHR$(9) THEN 188
194 PRINT@1306,STRING$(30,128);
195 NEXT
196 R=1:GOTO 181
197 '|||||||||||||||||||||||||||| PRINT SEARCH FILE |||||||||||||||||||||||||
198 LPRINT CHR$(27);CHR$(32):LPRINT CHR$(27);CHR$(14)
199 LPRINT A$(R,2):LPRINT A$(R,1):LPRINT A$(R,3):LPRINT A$(R,4)
200 LPRINT CHR$(27);CHR$(15):LPRINT CHR$(27);CHR$(31)
201 RETURN
202 '||||||||||||||||||||||||||| GLOBAL SEARCH ||||||||||||||||||||||||||||||
203 L=340
204 CLS:PRINT CHR$(23);"Global serching for '";CHR$(16);NN$;CHR$(17);"'":PRINT "<F1> to pause"
205 SIZE=LEN(NN$)
206 FOR R=1 TO LOF(1)
207 Z$=INKEY$:IF Z$=CHR$(129) THEN PRINT@80,"<E>nd <C>ontine":GOTO 213
208 FOR I=1 TO 22
209 IF NN$=MID$(A$(R,1),I,SIZE) THEN PRINT:GOSUB 217:GOTO 211
210 NEXT I
211 NEXT R
212 PRINT@1680,"<ANY KEY<"
213 Z$=INKEY$:IF Z$="" THEN 213
214 IF Z$="C" OR Z$="c" THEN PRINT@80,"<F1> to pause                ":GOTO 208
215 IF Z$="e" OR Z$="E" THEN 11
216 GOTO 11
217 '|||||| POST NUMBER ROUTINE ||||||
218 PRINT@L,"";
219 FOR J=1 TO 22
220 PRINT MID$(A$(R,1),J,1);:IF MID$(A$(R,1),J,1)=" " THEN 221 ELSE SOUND 0,0
221 NEXT
222 PRINT@L+80,CHR$(16);A$(R,2);CHR$(17)
223 L=L+240:IF L>1300 THEN L=340
224 RETURN
