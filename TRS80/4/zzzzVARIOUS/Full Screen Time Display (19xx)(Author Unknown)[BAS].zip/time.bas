1000   DIM A$(12),B$(12),C$(12),D$(12),E$(12),F$(12),G$(12),H$(12),I$(12)
1010   DIM J$(12),T$(12),X$(12)
1020   A$(1) = "     *******   ":A$(2) = "    *********  ":A$(3) = "   ***     *** ":A$(4) = "   **       ** "
1030   A$(5) = "   **       ** ":A$(6) = "   **       ** ":A$(7) = "   **       ** ":A$(8) = "   **       ** "
1040   A$(9) = "   **       ** ":A$(10) = "   ***     *** ":A$(11) = "    *********  ":A$(12) = "     *******   "
1050   B$(1) = "        **     ":B$(2) = "      ****     ":B$(3) = "     *****     ":B$(4) = "        **     "
1060   B$(5) = "        **     ":B$(6) = "        **     ":B$(7) = "        **     ":B$(8) = "        **     "
1070   B$(9) = "        **     ":B$(10) = "        **     ":B$(11) = "    ********** ":B$(12) = "    ********** "
1080   C$(1) = "    *********  ":C$(2) = "   *********** ":C$(3) = "            ** ":C$(4) = "            ** "
1090   C$(5) = "            ** ":C$(6) = "    ********** ":C$(7) = "   **********  ":C$(8) = "   **          "
1100   C$(9) = "   **          ":C$(10) = "   **          ":C$(11) = "   *********** ":C$(12) = "    ********** "
1110   D$(1) = "     *******   ":D$(2) = "    *********  ":D$(3) = "   **       ** ":D$(4) = "   **       ** "
1120   D$(5) = "            ** ":D$(6) = "       ******* ":D$(7) = "       ******* ":D$(8) = "            ** "
1130   D$(9) = "   **       ** ":D$(10) = "   **       ** ":D$(11) = "    *********  ":D$(12) = "     *******   "
1140   E$(1) = "   **       ** ":E$(2) = "   **       ** ":E$(3) = "   **       ** ":E$(4) = "   **       ** "
1150   E$(5) = "   *********** ":E$(6) = "    ********** ":E$(7) = "            ** ":E$(8) = "            ** "
1160   E$(9) = "            ** ":E$(10) = "            ** ":E$(11) = "            ** ":E$(12) = "            ** "
1170   F$(1) = "    *********  ":F$(2) = "   *********** ":F$(3) = "   **          ":F$(4) = "   **          "
1180   F$(5) = "   **          ":F$(6) = "   *********   ":F$(7) = "    *********  ":F$(8) = "            ** "
1190   F$(9) = "   **       ** ":F$(10) = "   **       ** ":F$(11) = "    *********  ":F$(12) = "     *******   "
1200   G$(1) = "    *********  ":G$(2) = "   **********  ":G$(3) = "   **          ":G$(4) = "   **          "
1210   G$(5) = "   **          ":G$(6) = "   **********  ":G$(7) = "   *********** ":G$(8) = "   **       ** "
1220   G$(9) = "   **       ** ":G$(10) = "   **       ** ":G$(11) = "   *********** ":G$(12) = "    *********  "
1230   H$(1) = "    *********  ":H$(2) = "   *********** ":H$(3) = "            ** ":H$(4) = "            ** "
1240   H$(5) = "            ** ":H$(6) = "            ** ":H$(7) = "            ** ":H$(8) = "            ** "
1250   H$(9) = "            ** ":H$(10) = "            ** ":H$(11) = "            ** ":H$(12) = "            ** "
1260   I$(1) = "     *******   ":I$(2) = "    *********  ":I$(3) = "   **       ** ":I$(4) = "   **       ** "
1270   I$(5) = "   **       ** ":I$(6) = "    *********  ":I$(7) = "    *********  ":I$(8) = "   **       ** "
1280   I$(9) = "   **       ** ":I$(10) = "   **       ** ":I$(11) = "    *********  ":I$(12) = "     *******   "
1290   J$(1) = "    *********  ":J$(2) = "   *********** ":J$(3) = "   **       ** ":J$(4) = "   **       ** "
1300   J$(5) = "   **       ** ":J$(6) = "   *********** ":J$(7) = "    ********** ":J$(8) = "            ** "
1310   J$(9) = "            ** ":J$(10) = "            ** ":J$(11) = "            ** ":J$(12) = "            ** "
1320   K$(1)  = " AAAAAAAAAAAAAA ":K$(2)  = "AA            AA":K$(3)  = "AA            AA":K$(4)  = "AA            AA"
1330   K$(5)  = "AAAAAAAAAAAAAAAA":K$(6)  = "AA            AA":K$(7)  = "AA            AA":K$(8)  = "AA            AA"
1340   K$(9)  = "AA            AA":L$(1)  = "   MM            MM":L$(2)  = "   MMM          MMM":L$(3)  = "   MM M        M MM"
1350   L$(4)  = "   MM  M      M  MM":L$(5)  = "   MM   M    M   MM":L$(6)  = "   MM    M  M    MM":L$(7)  = "   MM     MM     MM"
1360   L$(8)  = "   MM            MM":L$(9)  = "   MM            MM":M$(1)  = " PPPPPPPPPPPPPP ":M$(2)  = "PP            PP"
1370   M$(3)  = "PP            PP":M$(4)  = "PP            PP":M$(5)  = " PPPPPPPPPPPPPP ":M$(6)  = "PP              "
1380   M$(7)  = "PP              ":M$(8)  = "PP              ":M$(9)  = "PP              "
1390   X$(1) = "   ":X$(2) = "   ":X$(3) = "   ":X$(4) = "   ":X$(5) = " # ":X$(6) = "   ":X$(7) = "   "
1400   X$(8) = " # ":X$(9) = "   ":X$(10) = "   ":X$(11) = "   ":X$(12) = "   "
1410 PRINT CHR$(15)
1420 CLS
1430 A1$ = MID$(TIME$,1,2) : A2$ = MID$(TIME$,4,1) : A3$ = MID$(TIME$,5,1)
1440 B1 =  VAL(A1$) : B2 = VAL(A2$) : B3 = VAL(A3$)
1450 IF B1 = 0 THEN B1 = 12 : TM$ = "AM" : GOTO 1480
1460 IF B1 >=12 THEN TM$ = "PM" ELSE TM$ = "AM"
1470 IF B1 > 12 THEN B1 = B1 - 12
1480 NT1 = B1
1490 NT2 = B2
1500 NT3 = B3
1510 Z$ = INKEY$ : IF Z$ <> "" THEN PRINT CHR$(14) : RUN "MENU"
1520 IF OT2 = NT1+NT2+NT3 THEN GOTO 1430 ELSE OT2 = NT1+NT2+NT3
1530 PRINT @(0,0),;
1540 IF NT1 = 0 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+A4(A):NEXT A
1550 IF NT1 = 1 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+B$(A):NEXT A
1560 IF NT1 = 2 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+C$(A):NEXT A
1570 IF NT1 = 3 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+D$(A):NEXT A
1580 IF NT1 = 4 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+E$(A):NEXT A
1590 IF NT1 = 5 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+F$(A):NEXT A
1600 IF NT1 = 6 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+G$(A):NEXT A
1610 IF NT1 = 7 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+H$(A):NEXT A
1620 IF NT1 = 8 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+I$(A):NEXT A
1630 IF NT1 = 9 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A)+J$(A):NEXT A
1640 IF NT1 = 10 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+B$(A)+A$(A):NEXT A
1650 IF NT1 = 11 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+B$(A)+B$(A):NEXT A
1660 IF NT1 = 12 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+B$(A)+C$(A):NEXT A
1670 FOR A = 1 TO 12 :T$(A)=T$(A)+X$(A) : NEXT A
1680 IF NT2 = 0 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A):NEXT A
1690 IF NT2 = 1 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+B$(A):NEXT A
1700 IF NT2 = 2 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+C$(A):NEXT A
1710 IF NT2 = 3 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+D$(A):NEXT A
1720 IF NT2 = 4 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+E$(A):NEXT A
1730 IF NT2 = 5 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+F$(A):NEXT A
1740 IF NT2 = 6 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+G$(A):NEXT A
1750 IF NT2 = 7 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+H$(A):NEXT A
1760 IF NT2 = 8 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+I$(A):NEXT A
1770 IF NT2 = 9 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+J$(A):NEXT A
1780 IF NT3 = 0 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+A$(A):NEXT A
1790 IF NT3 = 1 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+B$(A):NEXT A
1800 IF NT3 = 2 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+C$(A):NEXT A
1810 IF NT3 = 3 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+D$(A):NEXT A
1820 IF NT3 = 4 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+E$(A):NEXT A
1830 IF NT3 = 5 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+F$(A):NEXT A
1840 IF NT3 = 6 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+G$(A):NEXT A
1850 IF NT3 = 7 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+H$(A):NEXT A
1860 IF NT3 = 8 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+I$(A):NEXT A
1870 IF NT3 = 9 THEN FOR A = 1 TO 12 :T$(A)=T$(A)+J$(A):NEXT A
1880 FOR A = 1 TO 12 : PRINT TAB(6); T$(A) : T$(A) = "" : NEXT A
1890 IF TX$ = TM$ THEN GOTO 1430
1900 IF TM$ = "AM" THEN FOR A = 1 TO 9 : Z$(A)=Z$(A)+K$(A)+L$(A) : NEXT A
1910 IF TM$ = "PM" THEN FOR A = 1 TO 9 : Z$(A)=Z$(A)+M$(A)+L$(A) : NEXT A
1920 PRINT @(13,0),
1930 FOR A = 1 TO 9 : PRINT TAB(22);Z$(A) : Z$(A)="" : NEXT A
1940 TX$ = TM$
1950 GOTO 1430
