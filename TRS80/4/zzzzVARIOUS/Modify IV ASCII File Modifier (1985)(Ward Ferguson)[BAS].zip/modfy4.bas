5 REM "MODIFY4/BAS" by WARD P. FERGUSON 70635,1314 -- (10/26/85)
6 CLEAR:DIM A$(1000):B2$=STRING$(79,"="):B3$=STRING$(79,"_"):B4$=STRING$(79,"_"):DEF FN B1$(TITLE$)=STRING$((79-LEN(TITLE$))/2," ")+TITLE$:B5$=FN B1$(STRING$(20,"-"))
7 SYSTEM "SYSTEM (BLINK=95)":DEF FN B2$(TITLE$)=STRING$((79-LEN(TITLE$))/2," ")+CHR$(16)+TITLE$+CHR$(17)
8 E$=CHR$(16)+"<N>"+CHR$(17)+" for NEXT line    "+CHR$(16)+"<I>"+CHR$(17)+" to INSERT line   "+CHR$(16)+"<S>"+CHR$(17)+" to SAVE last line":H$=CHR$(16)+"<F>"+CHR$(17)+" for FILE SAVE without further input":GOTO 23
9 CLS:PRINT FN B1$("OPTION #1"):PRINT B2$:PRINT FN B2$("=*= SEARCH / MODIFY =*="):PRINT B2$:PRINT"Input for file sought:":LINE INPUT"     Name of file saved in ASCII:  ";F$
10 LINE INPUT"     SEARCH FOR (alpha-numerics):  ";B$:PRINT B3$:OPEN"I",1,F$:FOR X=1 TO 1000:IF EOF(1) THEN Y=X-1:GOTO 12 ELSE LINE INPUT#1,A$(X):IF INSTR(A$(X),B$) THEN J$=A$(X):Z$=A$(X):GOSUB 44:PRINT
11 NEXT X
12 CLOSE:IF Z$="" THEN PRINT FN B1$("= NONE FOUND =")
13 PRINT B3$:PRINT FN B1$("=*= CHANGE PROGRAM MENU =*="):PRINT B2$:PRINT TAB(16)"* NOTE:  The length of the alpha-numerics changed":PRINT TAB(16)"must be the same both before and after the change!":PRINT B5$
14 PRINT"CHANGE alpha-numerics in named program:     {Key NULL [Press <ENTER>] or type ";CHR$(34);"END";CHR$(34);" to return to main menu}":LINE INPUT" FROM:  ";A$:IF (A$="") OR (A$="END") THEN 23 ELSE LINE INPUT"   TO:  ";C$
15 IF (C$="") OR (C$="END") THEN 23 ELSE GOSUB 35:FOR X=1 TO Y
16 Z=INSTR(A$(X),A$):IF Z THEN 17 ELSE 18
17 MID$(A$(X),Z)=C$:GOTO 16
18 NEXT X:CLOSE
19 PRINT B2$:PRINT FN B1$("=*= NEW FILE NAME =*="):PRINT B2$:PRINT TAB(16)"NOTE:   Show whole file name, for example:":PRINT TAB(28)CHR$(34);"FILESPEC/TXT:0";CHR$(34);",A"
20 PRINT TAB(16)"or the program will automatically use your":PRINT TAB(16)"original file name with a number inserted":PRINT TAB(16)"so as not to destroy your original program."
21 PRINT B5$:PRINT CHR$(34);F$;CHR$(34);" ended -- ";:LINE INPUT"new file name  ";N$:IF N$<>"" THEN G$=N$:PRINT B5$ ELSE PRINT B5$
22 PRINT"NEW ";CHR$(34);G$;CHR$(34);" is being saved as changed from OLD ";CHR$(34);F$;CHR$(34):PRINT B2$:OPEN"O",1,G$:FOR X=1 TO Y:PRINT#1,A$(X):NEXT X
23 CLOSE:CLS:I$="":C$="":X=0:Y=0:PRINT CHR$(15):PRINT B2$:PRINT FN B2$("=*=  MAIN MENU  =*="):PRINT B2$
24 PRINT"     Choose option by number:        1. SEARCH ascii file for alphanumerics           with MODIFY option        2. READ ascii file line-by-line           with SAVE/INSERT line option        3. LIST ascii disk file"
25 PRINT B5$:PRINT FN B1$("Any other key will END program"):PRINT B5$:PRINT FN B1$("(Either of the first two allows a new file to"):PRINT FN B1$("be created without change of the existing one")
26 PRINT FN B1$("---IF you follow directions.)"):PRINT FN B1$("________________________")
27 I$=INKEY$:IF I$="" THEN 27 ELSE IF I$="1" THEN GOTO 9 ELSE IF I$="2" THEN GOTO 29 ELSE IF I$="3" THEN PRINT B4$:INPUT"FILE NAME";F$:SYSTEM "LIST "+F$:PRINT B4$:PRINT FN B1$("<ENTER> to Continue"):LINE INPUT Z$:GOTO 23
28 PRINT FN B1$("  "+CHR$(16)+"Ending "+CHR$(34)+"MODIFY4/BAS"+CHR$(34)+CHR$(17)):PRINT CHR$(14):END
29 CLS:PRINT FN B1$("OPTION #2"):PRINT B2$:PRINT FN B2$("=*=  READ / SAVE =*="):PRINT B2$:INPUT"Name of file";F$:OPEN"I",1,F$:PRINT FN B1$("-----  ENTER  -----")
30 PRINT FN B1$(E$):PRINT FN B1$(H$):PRINT FN B1$("= Any other key will ABORT to main menu ="):PRINT B3$
31 I$=INKEY$:IF I$="" THEN 31 ELSE GOSUB 47:IF I$="F" THEN CLOSE:GOSUB 35:GOTO 19 ELSE IF I$="N" THEN PRINT"NEXT":GOSUB 34:LINE INPUT#1,A$:PRINT A$:GOTO 31 ELSE IF I$="I" THEN GOSUB 37:GOTO 31
32 IF I$="S" THEN PRINT"Saved":Y=Y+1:A$(Y)=A$:GOSUB 34:GOTO 31 ELSE CLOSE:PRINT B3$:INPUT"     File reading ABORTED, press <ENTER> for main menu";C$:GOTO 23
33 GOSUB 35:CLOSE:PRINT"Press <ENTER> for new file nameEnter ";CHR$(34);"M";CHR$(34);" to return to main menu";:INPUT C$:IF C$="M" OR C$="m" THEN 23 ELSE 19
34 IF EOF(1) THEN PRINT B3$:IF Y=0 THEN CLOSE:INPUT"End of file and no changes made so press <ENTER> for main menu";C$:GOTO 23 ELSE 33 ELSE RETURN
35 S1=INSTR(F$,"/"):IF (LEN(F$)<8) AND (S1=0) THEN G$=F$+"0" ELSE G$=F$:IF S1>0 THEN S1$=MID$(G$,(S1-1),1):GOSUB 41:MID$(G$,(S1-1),1)=S1$ ELSE S1$=MID$(G$,8,1):GOSUB 41:MID$(G$,8,1)=S1$
36 RETURN
37 PRINT"INSERT:":PRINT CHR$(14):LINE INPUT B$
38 Y=Y+1:A$(Y)=B$:A$="":B$="":RETURN
39 IF XY<>0 THEN 40 ELSE PRINT CHR$(14);:FOR XY=POS(0)TO 1023 STEP 64:C1=PEEK(XY+15360):IF C1<>95 THEN NEXT
40 XY=XY+1:PRINT CHR$(15);:RETURN
41 IF ASC(S1$)>80 THEN S1$="0" ELSE S1$=CHR$(ASC(S1$)+1)
42 RETURN
44 FOR V=1 TO LEN(J$):D$=MID$(J$,V,1):IF V=INSTR(J$,B$)THEN PRINT CHR$(16);:W=V-1
45 PRINT D$;:IF V=W+LEN(B$) THEN PRINT CHR$(17);:J$=RIGHT$(J$,LEN(J$)-V):GOTO 44
46 NEXT V:RETURN
47 I$=CHR$(ASC(I$) AND NOT 32):RETURN
