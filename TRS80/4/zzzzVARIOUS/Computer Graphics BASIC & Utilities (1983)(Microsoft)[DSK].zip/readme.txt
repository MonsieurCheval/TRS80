Computer Graphics (BASIC/Utilities)
v01.00.00
Model 4
Program Diskette
Drive 0
Cat. No. 26-1126
TRSDOS version 6.0

(c) Microsoft, Inc.

Dumped by Ira Goldklang at www.trs-80.com
