20 '  Robert Curtis   --  Sort Program Ver. 2.0  --  March, 1984 
40 '  BASED ON Machine Language SHELL METZNER sort by Allan Emert
60 ' MODEL 4 VERSION
80 '  MEMORY SIZE 61163 
100 CLS : PRINT "THIS IS THE MACHINE LANGUAGE ALPHABETIZING PROGRAM" 
120 PRINT  
140 PRINT  
160 PRINT "Robert Curtis                Version 2.0    March, 1984" 
180 PRINT  
200 PRINT  
220 CLEAR ,57344!: DEF USR = &HE000: DEFINT A - Z 
240 Z = 0 
260 GOSUB 700 
280 LINE INPUT "Input FILESPEC: ";FI$ 
300 LINE INPUT "Output FILESPEC: ";FO$ 
320 OPEN "I",1,FI$ 
340 T = 0 
360 LINE INPUT #1,A$:T = T + 1 
380 IF   EOF (1) THEN GOTO 400: ELSE GOTO 360 
400 CLOSE 1 
420 PRINT "Number of items to be sorted";T 
440 DIM A$(T) 
460 CLS : PRINT "READING DATA..." 
480 OPEN "I",1,FI$ 
500 FOR  I = 0 TO T - 1: LINE INPUT #1,A$(I) 
520 NEXT I: CLOSE : PRINT "SORTING..." 
540 X(0) = T 
560 X(1) = VARPTR (A$(0)) 
580 Z = USR ( VARPTR (X(0))) 
600 PRINT "SORT DONE!" 
620 OPEN "O",1,FO$ 
640 FOR  I = 0 TO T - 1: PRINT #1,A$(I): NEXT I 
660 CLOSE  
680 END  
700 '  LIST FOR 44K (ENTRY=&HE000) 
720 '  MEMORY SIZE=57344
740 N = 0 
760 FOR  I = 1 TO 208
780 READ A 
800 N = N + A 
820 POKE I - 8181,A
840 NEXT  
860 RETURN  
880 DATA 33 , 20 , 224 , 229 , 42 , 3 , 38 , 233 , 94 , 35 
900 DATA  86 , 237 , 83 , 36 , 224 , 35 , 94 , 35 , 86 , 237 , 83 , 10 , 224 , 33 , 0 , 0 , 34 , 8 , 224 , 237 , 91 , 8 
920 DATA  224 , 203 , 59 , 175 , 203 , 58 , 48 , 2 , 203 , 251 , 237 , 83 , 8 , 224 , 122 , 179 , 200 , 42 , 36 , 224 , 237 , 82 
940 DATA  34 , 4 , 224 , 33 , 0 , 0 , 34 , 2 , 224 , 42 , 2 , 224 , 34 , 0 , 224 , 42 , 0 , 224 , 237 , 91 , 8 , 224 
960 DATA  25 , 34 , 6 , 224 , 235 , 33 , 0 , 0 , 25 , 25 , 25 , 229 , 237 , 91 , 0 , 224 , 33 , 0 , 0 , 25 , 25 , 25 
980 DATA  237 , 75 , 10 , 224 , 9 , 235 , 225 , 9 , 229 , 213 , 14 , 0 , 126 , 71 , 26 , 184 , 48 , 3 , 14 , 1 , 71 , 175 
1000 DATA  176 , 40 , 25 , 197 , 19 , 35 , 78 , 35 , 70 , 197 , 225 , 235 , 78 , 35 , 70 , 197 , 225 , 193 , 26 , 150 , 56 , 10 
1020 DATA  32 , 39 , 19 , 35 , 16 , 246 , 203 , 65 , 32 , 31 , 209 , 225 , 6 , 3 , 78 , 235 , 126 , 113 , 235 , 119 , 35 , 19 
1040 DATA  16 , 246 , 42 , 8 , 224 , 235 , 42 , 0 , 224 , 175 , 237 , 82 , 34 , 0 , 224 , 48 , 144 , 24 , 2 , 209 , 225 , 42 
1060 DATA  2 , 224 , 17 , 1 , 0 , 175 , 25 , 34 , 2 , 224 , 237 , 91 , 4 , 224 , 237 , 82 , 218 , 75 , 224 , 195 , 41 , 224 
