1 '*** this program demonstraits the windowing capabilities of the RS hi-res
2 '*** graphics board.  the program draws circles and lines.  Press the 
3 '*** arrow keys to see the "rest" of the 1023x256 screen.  Press <SHIFT>
4 '*** <CLEAR> to instantly clear the graphics screen.  These capabilities
5 '*** can be included in your own program if you gosub the module at line
6 '*** 9000 exactly as is, at the beginning of your program.  See the docs
7 '*** "PORTS2.DOC" on DL8 for further information.
8 '***
10 GOSUB 9000 'SET UP 1024x256 GRAPHICS
20 X=RND(1024)-1:Y=RND(256)-1:R=RND(100)
30 LINE-(X,Y):CIRCLE(X,Y),R:A$=INKEY$:IF A$="" THEN 20
40 IF A$=CHR$(8) THEN FOR N=XP TO 0 STEP -1:OUT 140,N:NEXT:XP=0 '** left arrow pressed
50 IF A$=CHR$(9)THEN FOR N=XP TO 47:OUT 140,N:NEXT:XP=47'** right arrow pressed
60 IF A$=CHR$(10)THEN FOR N=YP TO 15:OUT 141,N:NEXT:YP=15'** down arrow pressed
70 IF A$=CHR$(11) THEN FOR N=YP TO 0 STEP -1:OUT 141,N:NEXT:YP=0'** up arrow pressed
80 IF A$=CHR$(31) THEN POKE FCLS,FON-1:CLR:POKE FCLS,FOFF
90 GOTO 20
8999 '***
9000 '*** this is the module that sets up the 1024x256 graphics.
9001 '*** it also allows a high-speed clr, by executing:
9002 '*** POKE FCLS,FON   to turn on high speed, and
9003 '*** POKE FLCS,FOFF  to turn it off.  With high speed clear, there
9004 '*** will be "snow" on the screen anytime you draw,erase, get, put, etc...
9005 '*** - but that is the price of speed.  if you don't want the screen 
9006 '*** displayed during the high speed access, POKE FCLS,FON-1.
9007 '*** The mixed text/graphics mode is also enabled.  Parameters for all
9008 '*** graphics commands are now x=0-1023 and y=0-255.  HAVE FUN!
9009 '***
9010 RESTORE 9030:FOR QN=&H8735 TO &H873C:READ QX:POKE QN,QX:NEXT QN:FOR QN=&H8784 TO &H8787:READ QX:POKE QN,QX:NEXT QN
9020 FCLS=&H871E:FON=253:FOFF=255:OUT 142,1:OUT 140,0:OUT 141,0:POKE FCLS,FON-1:CLR:CLS:POKE FCLS,FOFF:RETURN
9030 DATA 0,0,255,3,0,0,255,0,0,127,128,1
