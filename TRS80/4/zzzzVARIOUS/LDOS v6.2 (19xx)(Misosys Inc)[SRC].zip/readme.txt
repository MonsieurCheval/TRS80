;This collection of source code was typed (for typing practice
;and as an educational exercise) from Volume 1 of THE SOURCE.

;It contains all files required to construct a boot disk. Boot
;sectors can be written with DEBUG (see version 6 documentation)
;I have successfully assembled and booted "LS-DOS Level-xx" from
;these source files.

;The annotated source assembles without error using
;Disk-Editor-Assembler (D-E-A) by D. Goben. Every Hex byte was
;carefully compared to the original listing for correct
;addresses. Slight modifications to arithmetic syntax and some
;additional annotation were also made.

;Also included is a simple filter program, ADDLF.EXE which adds
;linefeeds to carriage return.
;usage:                         ADDCR <inpfile.ASM >oupfile.ASM


;06 JAN 1998
;Douglas Beattie Jr.             <beattidp@whidbey.net>
;