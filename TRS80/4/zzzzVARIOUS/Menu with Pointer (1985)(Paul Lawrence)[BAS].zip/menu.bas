0 ' MENU/BAS  CREATED:  05/18/85   REVISED:  12/28/85
1 ' By: Paul N. Lawrence PPN# 71455,271  Send EMAIL or LDOS SIG if you like it.
2 ' This program creates a menu screen with a pointer that can be moved
3 '      around to make menu selections.  When the pointer is at the item
4 '      of choice, press <ENTER> to branch to that choice.  Press <F3>
5 '      to ESC to routine referenced at line 10200.
6 ' The menu can be changed quickly by CHAINing another program with only
7 '      lines 10000 & up which contain the new branching instructions,
8 '      title, menu items, and print @ positions.
9 '      ie. CHAIN MERGE "filespec", 20, ALL (note:  the "20" IS important!)
10 '
15 CLS:DIM MENU$(19,1) ' array to hold menu selections
20 PRINT CHR$(15);CHR$(21);:RESTORE:READ TITLE$
21 ' curser off; alt char set (for pointer); reset data pointer; get new title
30 READ MESSAGE$ ' get bottom line message
40 PRINT @ 0,STRING$(40-(LEN(TITLE$)/2),198);TITLE$;STRING$(39-(LEN(TITLE$)/2),199);
41 PRINT @ (1,0),STRING$(80,"=");:PRINT @ (21,0),STRING$(80,"-");
42 ' center title & print graphics lines
50 PRINT @ (22,0),CHR$(30);LEFT$(MESSAGE$,79);' print prompt message
60 FOR X% = 0 TO 19:READ MENU$(X%,0):READ MENU$(X%,1):NEXT' read data into array
70 FOR X% = 0 TO 19:PRINT @ VAL(MENU$(X%,1)), LEFT$((MENU$(X%,0)+STRING$(25,32)),25);:NEXT
71 ' prt@ pos.(menu items)
80  P%=0: X$=CHR$(9):GOTO 270' init. P%(menu item pointer);point first menu item
198 '
199 '
200 FOR X%=0 TO 0:X$=INKEY$:X%=(X$=""):NEXT:PRINT @ VAL(MENU$(P%,1))-4,"   ";
201 ' wait for key; clear pointer
210 IF X$ = CHR$(11) THEN P%=P%-2:IF P%<0 THEN P%=19:GOTO 270 ' UP ARROW
220 IF X$ = CHR$(10) THEN P%=P%+2:IF P%>19 THEN P%=0:GOTO 270 ' DOWN ARROW
230 IF X$ = CHR$(8) THEN P%=P%-1:IF P%<0 THEN P%=19:GOTO 270 ' LEFT ARROW
240 IF X$ = CHR$(9) THEN P%=P%+1:IF P%>19 THEN P%=0:GOTO 270 ' RIGHT ARROW
250 IF X$ = CHR$(13) THEN GOTO 500 ' <ENTER> pressed
260 IF X$ = CHR$(131) THEN P%=20: GOTO 500 ' <F3> pressed (ESC)
270 IF MENU$(P%,0)=""THEN GOTO 210' if null then skip it
280 PRINT @ VAL(MENU$(P%,1))-4,CHR$(244);CHR$(245);CHR$(246);" ";:GOTO 200
281 ' prt new pointer; at new position
498 '
499 '
500 PRINT CHR$(21); ' all line branches thru here
510 ON P%+1 GOTO 10000,10010,10020,10030,10040,10050,10060,10070,10080,10090,10100,10110,10120,10130,10140,10150,10160,10170,10180,10190,10200:GOTO 200
511 ' branch on P%+1 after selection
9997 ' lines 10000 & up can CHAIN for different menus (menus can call menus)
9998 ' save all menus with "/MNU" extension
9999 ' the following lines are program branches to other programs or menus
10000 ' P%=1
10010 ' P%=2
10020 ' P%=3
10030 ' P%=4
10040 ' P%=5
10050 ' P%=6
10060 ' P%=7
10070 ' P%=8
10080 ' P%=9
10090 ' P%=10
10100 ' P%=11
10110 ' P%=12
10120 ' P%=13
10130 ' P%=14
10140 ' P%=15
10150 ' P%=16
10160 ' P%=17
10170 ' P%=18
10180 ' P%=19
10190 ' P%=20
10200 PRINT CHR$(14);: END' P%=21
10497 '
10498 '
10499 ' title$, message$, menu items, print @ positions (null to skip a position)
10500 DATA "  S U R V I V A L   O F   T H E   F I T T E S T  "
10510 DATA "      Use arrow keys to move pointer, <ENTER> to select, <F3> to go back"
10520 DATA "",170,"",210
10530 DATA ADD FOOD ITEMS,330,EDIT FOOD ITEMS,370
10540 DATA ADD RECIPE,490,EDIT RECIPE,530
10550 DATA DISPLAY FOOD LIST,650, PRINT FOOD LIST,690
10560 DATA DISPLAY RECIPE LIST,810, PRINT RECIPE LIST,850
10570 DATA SELECT RECIPES,970, EDIT RECIPE SELECTION,1010
10580 DATA DISPLAY SELECTED LIST,1130,PRINT SELECTED LIST,1170
10590 DATA CREATE FOOD ITEM INDEX,1290,CREATE RECIPE INDEX,1330
10600 DATA "",1450,"",1490
10610 DATA "",1610,"",1650
