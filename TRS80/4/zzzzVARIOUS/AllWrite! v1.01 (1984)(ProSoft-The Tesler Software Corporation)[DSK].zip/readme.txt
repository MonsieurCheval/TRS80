Model 4

This .dsk file disk bootable on drive 0.