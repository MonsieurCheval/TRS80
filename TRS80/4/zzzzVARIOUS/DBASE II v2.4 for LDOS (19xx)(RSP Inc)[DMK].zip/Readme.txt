DBase80 


dBase80 are the result of a patches series carried out to dBase II so that it could be run in computers Radio Shack Model IV, under the operative environment of LS-DOS 6.03.xx, and TRS-80 6.xx. 

A LITTLE OF HISTORY 

These patches was carried out between 1990 and 1992, when I needed a reliable and flexible database that worked with the operating system TRS-80 6.02 -and not with the archaic CPM - that had in that time on my only computer: a Model 4P. 

My beginnings in the computer World go back at 1989, when my curiosity for the computer science (I am a journalist) it took me to acquire a computer Radio Shack used Model 4P and very cheap. In that moment I didn't have the most remote idea of how these devices worked. Hardly, and with the help of the manual, I knew how to list in screen the directory of the disk. My Model's 4P configuration was the basic one: 64K of Ram and 2 drives of 184K. And with this same configuration I could carry out some programs of personal use in assembler (thank you Hardyn Brothers and 80 Micro) until my work summit: to modify dBase II to transport it to an operating system one excellent as LS-DOS or TRS-DOS 6.xx 

OPERATION 

dBase80 work exactly the same as dBase II, except for very few exceptions (see below) that have to do with the operating system. For that reason the on-line help of the own dBase II is the best guide for its efficient handling. To consent to the coarse help to write: 

. help dbase 

or 

. help (command) 

DBASE80 VS DBASEII 

The differences between one and another are given by the different handling of files on the part of LS-DOS and CPM. In dBase80 the extension always begins with the character "/" and not with "." For example, the basic files in dBase II are named: 
SAMPLE.DBF, SAMPLE.IDX, ETC. 

In dBase80: 
SAMPLE/DBF, SAMPLE/IDX, ETC. 

Another important difference is the extension of the application files (.CMD) in dBase. So that there is not incompatibility with the files executables of TRS-DOS (/CMD), this routine modified so that dBase 80 recognized the extension (/PRG) as application files. As you can see, this extension also corresponds to the files of application of dBase III. 
In dBaseII: sample.cmd 
In dBase80: sample/prg 

A great advantage in favor of dBase80 with regard to dBase II is that when working under the environment of LS-DOS there is not necessity that the main program are in the same disk (DBASE80/CMD), overlays (DBASEOVR/COM), the on-line help (DBASEMSG/TXT) and relative files to the database in use, since LS-DOS take charge of looking for in the disks the required files. 

However, to maintain total correspondence with dBase II, the internal commands were respected referred to drives and handling of files. This way, dBase80 recognize the successive drives like A (drive 0 in TRSDOS), B (drive 1), C (drive 2), D (drive 3)..., and when being initialized it always begins their operations in the drive A (drive 0) by default. If you wants to work with another drive (the drive 2, for example), the command in dBase80 is the same one that in dBase II: 

. Set default to C 

If you wants to see the files that there is in certain drive: 

. display files on B 

. display files like * / * on C 

. display files like * /PRG on A 

etc. 

BUGS 
Due to the strictly personal use of this program, I didn't leave bugs registrations or problems that could have dBase II working in another operative environment. The only command that with determination doesn't work well it is: 

. modify command 

To be an editor of very rudimentary text I only corrected the elementary thing. This command recognizes the extension /PRG by default, although it can also edit other files. However, this poor editor of text can be replaced peacefully by a more complex editor that can save in pure ASCII, if you wants to correct, to modify or to create applications for dBase80 with the extension /PRG. Editors as Allwrite, TED, Scripsit and others are good options. 

NOT FREEWARE NOT SHAREWARE 

These patches carried out to dBase II never pursued a commercial sense. They were made strictly for personal use. Therefore, dBase80 are not registered, is not entitled exclusive, neither it is modernized periodically.
But when beginning dBase 80 you will read the following notice: 

*************
If you like send $10 to 
 R.Muchela 
 C.C. 169 - 1B 
 1049 Buenos Aires 
 ARGENTINA 
*************
 
The $10 that I request are only a symbolic recognition to many working hours and enthusiasm to take the best database (dBase II) to the best operating system well-known (LS-DOS). But this neither is a contractual obligation on behalf of the remittent one neither mine. If you want to send $10, only make it motivated by their recognition will. 
Enjoy it.

Rodolfo Muchela 
muchela@ciudad.com.ar

--------------

GRATEFULNESS 
dBase 80 was tested with the extraordinary emulator of TRS-80 of David Keil (dmkeil@discover-net.net), to who I send him my warmest congratulations for his program and having made it of public domain. Thank you David. 


