CLS
.JCL to set up the MEMDisk, fill it with previously stored data, and make
.it the system drive :0.  Your present drive :0 will become drive :1, and
.the rest of the drives in your chain will be moved up accordingly.
.
SYSTEM (DRIVE=2,DRIVER="MEMDISK")  .Use different drive number if necessary
D
D
Y
MEMSYS (FDR) (R="BOOT")  .BOOT/CIM is the name of the stored MEMDisk data
MEMSYS (MOVE) :2   .Use the drive number you made your MEMDisk
SYSTEM (DRIVE=0,WP=YES)   .Write protect the MEMDisk system
.
.You are now operating your computer from the MEMDisk.
//EXIT
