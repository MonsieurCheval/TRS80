5 ' April 24, 1983
10 CLEAR 1000
20 A$="#pds#"
30 B$="/"+"#ext#"
50 OPEN"i",1,"file/txt:1"
60 LINEINPUT#1,C$                 ' Get rid of heading
70 IF EOF(1) THEN CLOSE:CMD"s"
80 LINEINPUT#1,C$                 ' Get line
85 IF LEN(C$)<5 THEN 70
90 C%=INSTR(C$,CHR$(32))           ' Find first space
100 D$="pds (copy) "+A$+" ("+LEFT$(C$,C%-1)+") "+LEFT$(C$,C%-1)+B$
105 PRINT D$
110 CMD D$                        ' Do it
120 IF LEN(C$)<32 THEN 70 ELSE C$=MID$(C$,31):GOTO 90
