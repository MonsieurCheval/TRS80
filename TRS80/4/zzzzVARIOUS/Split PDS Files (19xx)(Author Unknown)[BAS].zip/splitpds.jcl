. April 24, 1983
. This JCL file will copy a PDS's individual members
. into files which can be accessed from LDOS.
. Syntax:
.  do splitpds (pds=pdsname,ext=desired extension:drive)
. Drive should be specified
.
. Note! File/txt must not exist!
.
route *pr file/txt:1
pds (dir) #pds# (p)
reset *pr
lbasic load"splitpds"
20 a$="#pds#"
30 b$="/"+"#ext#"
run
kill file/txt
. The end!
