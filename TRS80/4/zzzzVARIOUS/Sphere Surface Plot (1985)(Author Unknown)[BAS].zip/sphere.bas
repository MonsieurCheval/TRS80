10 '    Hi-Res Sphere 3-D surface plot for Micro-Labs GBASIC - Model IV
20 '    Modified from a program for the EPSON MX80 by Bob Boothe
30 '    Modifications for Model 4 GBASIC, Hi-Res video and remarks by Chuck Bell
50 '    Equation of a sphere is: X^2 + Y^2 + Z^2 = 1
80 DEFINT Q, B, L:DIM L(511)
100 CLS:@CLS:@ON    'Change to CLS:CLR:SCREEN 0 for Radio Shack BASICG
110 ' Change following line to  PRINT CHR$(15):GLOCATE(0,0),0:PRINT #-3 "Hi-Res Sphere" for Radio Shack BASICG
120 PRINT CHR$(15):@POS(0,0,0):PRINT "Hi-Res Sphere"
140 K=1/128:T=1/8192:X=1:Y=1:C=1:Q=1:S=1:A=1:MY=1
150 '   Change to STEP 1/120 for 640 x 240 model 4 resolution
160 FOR C=-1 TO 1 STEP 1/96         ' No. of horizontal lines (2*96=192)
180 B=B+1
190 MY=SQR(1-C*C)-T                 'Find maximum value of Y
200 Y=-MY
210 X=SQR(1-Y*Y-C*C)+T              'Solve for X in terms of Y and Z (+ Tiny)
220 A=SQR((1+Y*Y/X/X)*(1+C*C/X/X))  'Find relative area
225 '   Change to S=1/A/22 for 640 x 240 model 4 resolution
230 S=1/A/20                   'Compute step across Y-axis to plot next point
240 IF S<K THEN S=K                 'Compare step to minimum value of K
250 Y=Y+S
255 '   Change to L(FIX(240+MY+239)=1 for 640 x 240 model 4 resolution
260 IF Y>MY THEN L(FIX(192+MY*191))=1:GOTO 290
265 '   Change to L(FIX(240+Y*239)=1 for 640 x 240 model 4 resolution
270 L(FIX(192+Y*191))=1             'Add point to the array
280 GOTO 210
285 '   Change following line to FOR Q=0 TO 511:IF L(Q)=1 THEN PSET(Q,B)  for Radio Shack BASICG
290 FOR Q=0 TO 511:IF L(Q)=1 THEN @PLOT(Q,B,1)
300 L(Q)=0: NEXT
310 NEXT C
320 GOTO 320
