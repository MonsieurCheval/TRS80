
Duplicat Model 3 and 4 (?)
this is another of the copy-proof disks.
be sure to read-protect this disk and
turn off the printer when using. some 
copy-proof programs get mad and try to
distroy everything.

This .dsk file is bootable on drive 0.