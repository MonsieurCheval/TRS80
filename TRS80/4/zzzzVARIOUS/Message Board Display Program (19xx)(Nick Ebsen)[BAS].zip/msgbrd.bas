1 '**************************************************************
2 '*                                                            *
3 '*           MESSAGE BOARD DISPLAY PROGRAM                    *
4 '*           BY   NICK EBSEN   (73756,401)                    *
5 '*                                                            *
6 '**************************************************************
7 '
8 '
9 '  INSERT THIS ROUTINE IN A PROGRAM THAT DRAWS A PICTURE
10 ' AND CHANGE THE DATA LINES (2000-) TO DISPLAY A MESSAGE
11 ' THAT IS USEFUL TO YOU, YOUR BUSINESS, CLUB OR WHATEVER
12 '
13 '
15 ' YOU MAY CHANGE VARIABLES W&T TO CONSTANTS FOR YOUR
16 ' MACHINE TO MAKE IT RUN SMOOTHER
17 '
18 '
100 CLEAR 1000:CLS
110 PRINT CHR$(15) '        ELIMINATES THE CURSOR --VERY DISTRACTING--
120 PRINT@0,"JUST ONE MOMENT PLEASE       OR MAYBE TWO"
130 DIM S(255,5) '        CHANGE SECOND DIMENSION TO MATCH YOUR STRINGS
140 W=80 '                SCREEN WIDTH FOR MOD4  CHANGE FOR OTHERS (64,32 ETC)
150 T=50 '                TIMER FOR MOD4  CHANGE FOR CLOCK RATE OR YOUR TASTE
160 P=0
170 READ S$
180 IF S$="END" THEN GOTO 1000
190 P=P+1
200 S(0,P)=LEN(S$)
210 FOR C=1 TO S(0,P)
220 S(C,P)=ASC(MID$(S$,C,1))
230 NEXT C
240 GOTO 170
1000 S$=STRING$(W,32)
1010 FOR SP=1 TO P
1020 FOR SL=1 TO S(0,SP)
1030 S$=RIGHT$(S$,W-1)+CHR$(S(SL,SP))
1040 PRINT@0,S$;
1050 FOR DT=1 TO T:NEXT DT
1060 NEXT SL
1070 NEXT SP
1080 GOTO 1010
2000 DATA "MESSAGE BOARD     BY  ***** NICK EBSEN *****  (73756,401)   SEE YOUR MESSAGE HERE     UP IN LIGHTS       (JUST LIKE TIMES SQUARE  HUH?)                                                           ADVERTISEMENTS,                                "
2010 DATA "WIDGETS   REDUCED FOR THE FIRST TIME EVER   FOR SALE HERE ONLY      AT THE REDICULOUS PRICE                        NEVER BEFORE SEEN  (WELL ALMOST NEVER)  IN THIS CENTURY                         OF ONLY                                   "
2020 DATA "TWENTY FOUR HUNDRED DOLLARS                                                     (THEY ARE VERY HIGH CLASS WIDGETS)                                                                                CLUB ANNOUNCEMENTS                          "
2030 DATA " THE NEXT MEETING OF HACKERS ANONYMOUS WILL BE IN DECEMBER                                  WE DECIDED THAT THESE CONTINUAL MEETINGS WERE TAKING VALUABLE TIME AWAY FROM THE KEYBOARD                                                        "
2040 DATA "                     ANYTHING THAT YOU WANT EYE-CATCHING INFORMATION TO BE DISPLAYED FOR       JUST TYPE IN THE DATA LINES                                                 COMPUTING CAN BE USEFUL FOR MORE THAN RECORD KEEPING              "
5000 DATA "END"
